"""
8. uzdevums

Parāda 5 pāra skaitļus sākot no 4.

Izveidoja: Dmytro Polizhai
"""

for n in range(4, 14, 2):
    print(n)