"""
7. uzdevums

Parāda šādu vērtību tabulu, veselo skaitļu no 1 līdz 5 kubi

Izveidoja: Dmytro Polizhai
"""
from math import sqrt

print("-" * 27)
print(" Skaitlis  | Skaitlis kubā")
print("-" * 27)

for n in range(1, 6):
    print(f"  {n}        | {n**3}")

print("-" * 27)