"""
6. uzdevums

Aprēķina skaitļa 2 pakāpēs no 2. līdz 5. pakāpei.

Izveidoja: Dmytro Polizhai
"""

for i in range(2, 6):
    print(f"2^{i}={2**i}")