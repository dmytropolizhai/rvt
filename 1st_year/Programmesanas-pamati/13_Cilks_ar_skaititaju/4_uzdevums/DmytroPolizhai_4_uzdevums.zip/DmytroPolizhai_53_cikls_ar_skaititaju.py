"""
1. uzdevums

Parāda 2 reizrēķinu (reizināšanas tabulu)

Izveidoja: Dmytro Polizhai
"""

for n in range(1, 10):
    print(f"2 x {n} = {n * 2}")