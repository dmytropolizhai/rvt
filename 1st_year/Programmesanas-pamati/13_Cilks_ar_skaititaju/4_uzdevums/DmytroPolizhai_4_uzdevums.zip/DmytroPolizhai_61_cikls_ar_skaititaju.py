"""
9. uzdevums

Saskaita 5 veselu skaitļu summu sākot no 3. skaitļa

Izveidoja: Dmytro Polizhai
"""

sum_ = 0

for n in range(3, 9):
    sum_ += n

print("5 veselu skaitļu summa sākot no 3. skaitļa ir", sum_)