"""
Visvienkāršākā programma ar ciklu for
Izvada: skaitļus no 1 līdz 6 (6 ieskaitot)

Izveidoja: Dmytro Polizhai
"""

for x in range(1, 6):
    print(x, end="\t")