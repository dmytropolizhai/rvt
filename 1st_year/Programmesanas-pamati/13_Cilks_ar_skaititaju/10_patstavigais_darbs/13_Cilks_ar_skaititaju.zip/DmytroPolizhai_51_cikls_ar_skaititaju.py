"""
Parāda piecus nepāra skaitļus sākot no 7 (1. veids)
Izveidoja: Dmytro Polizhai
"""

for n in range(7, 17):
    if n % 2 != 0:
        print(n)