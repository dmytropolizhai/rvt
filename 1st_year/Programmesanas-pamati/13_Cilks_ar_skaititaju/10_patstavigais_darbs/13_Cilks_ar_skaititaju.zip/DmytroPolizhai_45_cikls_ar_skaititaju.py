"""
Visvienkāršākā programma ar ciklu for
Izvada: skaitļus no 2 līdz 11 (11 neieskaitot) ar soli 2

Izveidoja: Dmytro Polizhai
"""

for x in range(2, 11, 2):
    print(x, end="\t")