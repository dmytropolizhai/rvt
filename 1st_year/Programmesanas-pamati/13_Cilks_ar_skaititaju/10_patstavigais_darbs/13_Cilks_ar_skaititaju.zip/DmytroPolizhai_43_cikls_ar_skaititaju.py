"""
Visvienkāršākā programma ar ciklu for
Izvada: skaitļus no 0 līdz 5 (5 neieskaitot)

Izveidoja: Dmytro Polizhai
"""

for x in range(5):
    print(x, end="\t")