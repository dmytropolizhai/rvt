"""
Parāda piecus nepāra skaitļus sākot no 7 (2.veids)

Izveidoja: Dmytro Polizhai
"""

for n in range(7, 17, 2):
    print(n)

    