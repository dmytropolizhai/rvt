"""
Kas aprēķina skaitļa trīs pakāpēs līdz 6 pakāpei.

Izveidoja: Dmytro Polizhai
"""

for p in range(1, 7):
    print(f"3^{p}={3**p}")