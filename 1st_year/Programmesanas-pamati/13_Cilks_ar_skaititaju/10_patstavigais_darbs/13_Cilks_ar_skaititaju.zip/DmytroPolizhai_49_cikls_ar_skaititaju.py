"""
Saskaita četru pēc kārtas esošu skaitļu summu. 

Izveidoja: Dmytro Polizhai
"""

sum_ = 0

for k in range(1, 5):
    sum_ += k

print(sum_)