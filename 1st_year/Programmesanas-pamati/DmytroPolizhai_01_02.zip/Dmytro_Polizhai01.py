# Mana pirmā programma
# Programma izvada tekstu

print("Sveika, pasaule!")
